function subTotal(obj) {
    let amount = 0;
  let defaultDegree = 5000;
  let defaultCerti = 3000;
  let defaultDiploma = 2500
    for (let key in obj) {
      switch(key){
        case('DEGREE'):{
        amount += defaultDegree * obj[key];
        break;
        }
        case('CERTIFICATION'):{
        amount += defaultCerti * obj[key];
        break
        }
        default : {
        amount += defaultDiploma * obj[key];
        break;
        }
      }
      
    }
    return amount;
  }

  module.exports = {subTotal}